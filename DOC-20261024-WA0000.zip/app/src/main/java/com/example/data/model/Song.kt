package com.example.data.model

data class LyricLine(
    val timeMs: Long,
    val text: String
)

data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val durationSeconds: Int,
    val streamUrl: String,
    val localFilePath: String? = null,
    val coverDrawableRes: Int? = null,
    val coverUrl: String? = null,
    val coverColorHex: Long = 0xFF6366F1,
    val isDownloaded: Boolean = false,
    val isFavorite: Boolean = false,
    val lyrics: List<LyricLine> = emptyList(),
    val playCount: Int = 0
) {
    val durationFormatted: String
        get() {
            val minutes = durationSeconds / 60
            val seconds = durationSeconds % 60
            return "%d:%02d".format(minutes, seconds)
        }
}

enum class RepeatMode {
    OFF,
    ALL,
    ONE
}

enum class EqualizerPreset(val label: String, val bassMultiplier: Float, val trebleMultiplier: Float) {
    FLAT("Flat", 1.0f, 1.0f),
    BASS_BOOST("Bass Boost", 1.8f, 0.9f),
    VOCAL("Vocal Booster", 0.8f, 1.6f),
    ELECTRONIC("Electronic", 1.5f, 1.4f),
    ROCK("Rock & Metal", 1.4f, 1.2f),
    ACOUSTIC("Acoustic Warm", 1.1f, 1.2f)
}

data class DownloadProgress(
    val songId: String,
    val progress: Float, // 0.0 to 1.0
    val isComplete: Boolean,
    val error: String? = null
)

data class Playlist(
    val id: String,
    val title: String,
    val description: String,
    val songIds: List<String>,
    val createdAt: Long = System.currentTimeMillis()
)
