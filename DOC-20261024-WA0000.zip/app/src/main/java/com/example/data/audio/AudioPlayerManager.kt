package com.example.data.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.data.model.EqualizerPreset
import com.example.data.model.RepeatMode
import com.example.data.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.random.Random

class AudioPlayerManager(private val context: Context) {

    private val tag = "AudioPlayerManager"
    private var mediaPlayer: MediaPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _repeatMode = MutableStateFlow(RepeatMode.ALL)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _equalizerPreset = MutableStateFlow(EqualizerPreset.FLAT)
    val equalizerPreset: StateFlow<EqualizerPreset> = _equalizerPreset.asStateFlow()

    private val _sleepTimerSeconds = MutableStateFlow<Int?>(null)
    val sleepTimerSeconds: StateFlow<Int?> = _sleepTimerSeconds.asStateFlow()

    private val _visualizerAmplitudes = MutableStateFlow(List(16) { 0.2f })
    val visualizerAmplitudes: StateFlow<List<Float>> = _visualizerAmplitudes.asStateFlow()

    private var currentPlaylist: List<Song> = emptyList()
    private var playbackPollingJob: Job? = null
    private var sleepTimerJob: Job? = null

    init {
        startPollingPlayback()
    }

    private fun startPollingPlayback() {
        playbackPollingJob?.cancel()
        playbackPollingJob = scope.launch {
            while (isActive) {
                mediaPlayer?.let { player ->
                    try {
                        if (player.isPlaying) {
                            _currentPositionMs.value = player.currentPosition.toLong()
                            val dur = player.duration.toLong()
                            if (dur > 0) _durationMs.value = dur

                            // Generate smooth visualizer levels based on playback & equalizer preset
                            val preset = _equalizerPreset.value
                            val baseSpeed = _playbackSpeed.value
                            val bars = List(16) { index ->
                                val wave = (Math.sin((_currentPositionMs.value / 150.0) + index * 0.45) + 1.0) / 2.0
                                val randomJitter = Random.nextFloat() * 0.35f
                                val bassBoost = if (index < 5) preset.bassMultiplier else 1.0f
                                val trebleBoost = if (index > 10) preset.trebleMultiplier else 1.0f
                                ((wave * 0.6 + randomJitter) * bassBoost * trebleBoost).toFloat().coerceIn(0.12f, 1.0f)
                            }
                            _visualizerAmplitudes.value = bars
                        } else {
                            // Dim visualizer bars when paused
                            _visualizerAmplitudes.value = List(16) { 0.15f }
                        }
                    } catch (e: Exception) {
                        // ignore state transitions
                    }
                }
                delay(100)
            }
        }
    }

    fun playSong(song: Song, playlist: List<Song> = emptyList()) {
        if (playlist.isNotEmpty()) {
            currentPlaylist = playlist
        } else if (!currentPlaylist.any { it.id == song.id }) {
            currentPlaylist = listOf(song)
        }

        _currentSong.value = song
        _currentPositionMs.value = 0L
        _durationMs.value = (song.durationSeconds * 1000).toLong()

        setupAndStartPlayer(song)
    }

    private fun setupAndStartPlayer(song: Song) {
        releasePlayer()

        try {
            val player = MediaPlayer()
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )

            // 1. Check if downloaded local file exists
            val localFile = if (song.localFilePath != null) File(song.localFilePath) else null
            val downloadsDir = File(context.filesDir, "downloads")
            val downloadedAudio = File(downloadsDir, "song_${song.id}.audio")

            when {
                localFile != null && localFile.exists() && localFile.length() > 0 -> {
                    player.setDataSource(context, Uri.fromFile(localFile))
                    prepareAndStart(player, song)
                }
                downloadedAudio.exists() && downloadedAudio.length() > 0 -> {
                    player.setDataSource(context, Uri.fromFile(downloadedAudio))
                    prepareAndStart(player, song)
                }
                song.streamUrl.startsWith("http://") || song.streamUrl.startsWith("https://") -> {
                    // Try online stream with graceful fallback
                    player.setDataSource(song.streamUrl)
                    player.setOnPreparedListener {
                        try {
                            applyPlaybackParams(player)
                            player.start()
                            _isPlaying.value = true
                            _durationMs.value = player.duration.toLong()
                        } catch (e: Exception) {
                            Log.e(tag, "Start online player failed", e)
                            fallbackToGeneratedAudio(song)
                        }
                    }
                    player.setOnErrorListener { _, what, extra ->
                        Log.w(tag, "Streaming failed ($what, $extra), switching to fallback audio")
                        fallbackToGeneratedAudio(song)
                        true
                    }
                    player.prepareAsync()
                }
                else -> {
                    fallbackToGeneratedAudio(song)
                }
            }

            player.setOnCompletionListener {
                handleSongCompletion()
            }

            mediaPlayer = player

        } catch (e: Exception) {
            Log.e(tag, "Error setting up player, using local synthesis", e)
            fallbackToGeneratedAudio(song)
        }
    }

    private fun prepareAndStart(player: MediaPlayer, song: Song) {
        player.prepare()
        applyPlaybackParams(player)
        player.start()
        _isPlaying.value = true
        _durationMs.value = player.duration.toLong()
    }

    private fun fallbackToGeneratedAudio(song: Song) {
        scope.launch(Dispatchers.IO) {
            val fallbackWav = AudioGenerator.createSongWavFile(context, song.id, song.durationSeconds.coerceAtMost(45))
            scope.launch(Dispatchers.Main) {
                releasePlayer()
                try {
                    val fallbackPlayer = MediaPlayer()
                    fallbackPlayer.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .build()
                    )
                    fallbackPlayer.setDataSource(context, Uri.fromFile(fallbackWav))
                    fallbackPlayer.prepare()
                    applyPlaybackParams(fallbackPlayer)
                    fallbackPlayer.start()
                    _isPlaying.value = true
                    _durationMs.value = fallbackPlayer.duration.toLong()
                    fallbackPlayer.setOnCompletionListener {
                        handleSongCompletion()
                    }
                    mediaPlayer = fallbackPlayer
                } catch (e: Exception) {
                    Log.e(tag, "Fallback playback error", e)
                }
            }
        }
    }

    private fun applyPlaybackParams(player: MediaPlayer) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val params = player.playbackParams ?: PlaybackParams()
                params.speed = _playbackSpeed.value
                player.playbackParams = params
            } catch (e: Exception) {
                Log.w(tag, "Could not set playback params", e)
            }
        }
    }

    fun togglePlayPause() {
        val player = mediaPlayer ?: run {
            _currentSong.value?.let { playSong(it, currentPlaylist) }
            return
        }

        try {
            if (player.isPlaying) {
                player.pause()
                _isPlaying.value = false
            } else {
                applyPlaybackParams(player)
                player.start()
                _isPlaying.value = true
            }
        } catch (e: Exception) {
            _isPlaying.value = false
        }
    }

    fun seekTo(positionMs: Long) {
        mediaPlayer?.let { player ->
            try {
                player.seekTo(positionMs.toInt())
                _currentPositionMs.value = positionMs
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun skipForward10() {
        val current = _currentPositionMs.value
        val dur = _durationMs.value
        val newPos = (current + 10000L).coerceAtMost(dur)
        seekTo(newPos)
    }

    fun skipBackward10() {
        val current = _currentPositionMs.value
        val newPos = (current - 10000L).coerceAtLeast(0L)
        seekTo(newPos)
    }

    fun playNext() {
        if (currentPlaylist.isEmpty()) return
        val current = _currentSong.value ?: return

        val nextIndex = if (_isShuffle.value) {
            Random.nextInt(currentPlaylist.size)
        } else {
            val idx = currentPlaylist.indexOfFirst { it.id == current.id }
            if (idx == -1 || idx == currentPlaylist.lastIndex) 0 else idx + 1
        }

        val nextSong = currentPlaylist[nextIndex]
        playSong(nextSong, currentPlaylist)
    }

    fun playPrevious() {
        if (currentPlaylist.isEmpty()) return
        val current = _currentSong.value ?: return

        val idx = currentPlaylist.indexOfFirst { it.id == current.id }
        val prevIndex = when {
            _currentPositionMs.value > 3000 -> idx // restart current song if >3s
            idx <= 0 -> currentPlaylist.lastIndex
            else -> idx - 1
        }

        val prevSong = currentPlaylist[prevIndex.coerceIn(0, currentPlaylist.lastIndex)]
        playSong(prevSong, currentPlaylist)
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        mediaPlayer?.let { player ->
            applyPlaybackParams(player)
        }
    }

    fun toggleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
    }

    fun toggleShuffle() {
        _isShuffle.value = !_isShuffle.value
    }

    fun setEqualizerPreset(preset: EqualizerPreset) {
        _equalizerPreset.value = preset
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _sleepTimerSeconds.value = null
            return
        }

        var remaining = minutes * 60
        _sleepTimerSeconds.value = remaining

        sleepTimerJob = scope.launch {
            while (remaining > 0 && isActive) {
                delay(1000)
                remaining--
                _sleepTimerSeconds.value = remaining
            }
            // Timer expired: stop music smoothly
            pausePlayer()
            _sleepTimerSeconds.value = null
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _sleepTimerSeconds.value = null
    }

    private fun handleSongCompletion() {
        when (_repeatMode.value) {
            RepeatMode.ONE -> {
                seekTo(0L)
                mediaPlayer?.start()
                _isPlaying.value = true
            }
            RepeatMode.ALL -> {
                playNext()
            }
            RepeatMode.OFF -> {
                val current = _currentSong.value
                val idx = currentPlaylist.indexOfFirst { it.id == current?.id }
                if (idx != -1 && idx < currentPlaylist.lastIndex) {
                    playNext()
                } else {
                    _isPlaying.value = false
                    seekTo(0L)
                }
            }
        }
    }

    private fun pausePlayer() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                _isPlaying.value = false
            }
        }
    }

    private fun releasePlayer() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            // ignore
        }
        mediaPlayer = null
    }

    fun release() {
        playbackPollingJob?.cancel()
        sleepTimerJob?.cancel()
        releasePlayer()
    }
}
