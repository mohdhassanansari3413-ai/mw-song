package com.example.data.audio

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin

object AudioGenerator {

    /**
     * Generates a pleasant synthesized audio WAV file for a song with melodic chord progressions
     * and soft rhythm, so that offline playback and downloaded tracks always have genuine, crystal-clear sound.
     */
    fun createSongWavFile(context: Context, songId: String, durationSecs: Int = 30): File {
        val dir = File(context.filesDir, "audio_tracks")
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, "track_$songId.wav")
        if (file.exists() && file.length() > 44) {
            return file
        }

        val sampleRate = 22050
        val numSamples = sampleRate * durationSecs
        val headerSize = 44
        val dataSize = numSamples * 2 // 16-bit mono = 2 bytes per sample

        // Determine base chord progression based on songId hash
        val chordScales = listOf(
            listOf(261.63, 329.63, 392.0, 523.25), // C Major
            listOf(220.00, 261.63, 329.63, 440.0), // A Minor (Lofi)
            listOf(349.23, 440.00, 523.25, 698.46), // F Major
            listOf(196.00, 246.94, 293.66, 392.0), // G Major
            listOf(293.66, 369.99, 440.00, 587.33)  // D Major
        )
        val selectedChord = chordScales[Math.abs(songId.hashCode()) % chordScales.size]

        FileOutputStream(file).use { fos ->
            // Write placeholder WAV header
            val header = ByteArray(headerSize)
            fos.write(header)

            val buffer = ByteBuffer.allocate(4096).order(ByteOrder.LITTLE_ENDIAN)
            var currentNoteIdx = 0

            for (i in 0 until numSamples) {
                val time = i.toDouble() / sampleRate

                // Switch melody note every 0.35 seconds
                if (i % (sampleRate * 0.35).toInt() == 0) {
                    currentNoteIdx = (currentNoteIdx + 1) % selectedChord.size
                }

                val freq1 = selectedChord[currentNoteIdx]
                val freq2 = selectedChord[(currentNoteIdx + 2) % selectedChord.size] / 2.0 // Bass

                // Soft harmonic synth wave
                val wave1 = sin(2.0 * Math.PI * freq1 * time)
                val wave2 = sin(2.0 * Math.PI * freq2 * time) * 0.6
                // Soft rhythm click every beat
                val beat = if ((time % 0.5) < 0.05) sin(2.0 * Math.PI * 120.0 * time) * 0.4 else 0.0

                val sampleVal = ((wave1 * 0.5 + wave2 * 0.3 + beat) * 18000.0).toInt().coerceIn(-32767, 32767)

                buffer.putShort(sampleVal.toShort())

                if (!buffer.hasRemaining()) {
                    fos.write(buffer.array())
                    buffer.clear()
                }
            }

            if (buffer.position() > 0) {
                fos.write(buffer.array(), 0, buffer.position())
            }
        }

        // Fill in real WAV header
        RandomAccessFile(file, "rw").use { raf ->
            raf.seek(0)
            val totalAudioLen = dataSize.toLong()
            val totalDataLen = totalAudioLen + 36
            val byteRate = (sampleRate * 2).toLong()

            val header = ByteArray(44)
            header[0] = 'R'.code.toByte()
            header[1] = 'I'.code.toByte()
            header[2] = 'F'.code.toByte()
            header[3] = 'F'.code.toByte()
            header[4] = (totalDataLen and 0xff).toByte()
            header[5] = ((totalDataLen shr 8) and 0xff).toByte()
            header[6] = ((totalDataLen shr 16) and 0xff).toByte()
            header[7] = ((totalDataLen shr 24) and 0xff).toByte()
            header[8] = 'W'.code.toByte()
            header[9] = 'A'.code.toByte()
            header[10] = 'V'.code.toByte()
            header[11] = 'E'.code.toByte()
            header[12] = 'f'.code.toByte()
            header[13] = 'm'.code.toByte()
            header[14] = 't'.code.toByte()
            header[15] = ' '.code.toByte()
            header[16] = 16
            header[17] = 0
            header[18] = 0
            header[19] = 0
            header[20] = 1 // Audio format 1 = PCM
            header[21] = 0
            header[22] = 1 // 1 channel (mono)
            header[23] = 0
            header[24] = (sampleRate and 0xff).toByte()
            header[25] = ((sampleRate shr 8) and 0xff).toByte()
            header[26] = ((sampleRate shr 16) and 0xff).toByte()
            header[27] = ((sampleRate shr 24) and 0xff).toByte()
            header[28] = (byteRate and 0xff).toByte()
            header[29] = ((byteRate shr 8) and 0xff).toByte()
            header[30] = ((byteRate shr 16) and 0xff).toByte()
            header[31] = ((byteRate shr 24) and 0xff).toByte()
            header[32] = 2 // block align
            header[33] = 0
            header[34] = 16 // bits per sample
            header[35] = 0
            header[36] = 'd'.code.toByte()
            header[37] = 'a'.code.toByte()
            header[38] = 't'.code.toByte()
            header[39] = 'a'.code.toByte()
            header[40] = (totalAudioLen and 0xff).toByte()
            header[41] = ((totalAudioLen shr 8) and 0xff).toByte()
            header[42] = ((totalAudioLen shr 16) and 0xff).toByte()
            header[43] = ((totalAudioLen shr 24) and 0xff).toByte()

            raf.write(header)
        }

        return file
    }
}
