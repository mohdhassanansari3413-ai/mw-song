package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.audio.AudioGenerator
import com.example.data.downloader.SongDownloadManager
import com.example.data.model.LyricLine
import com.example.data.model.Playlist
import com.example.data.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class MusicRepository(
    private val context: Context,
    val downloadManager: SongDownloadManager
) {
    private val scope = CoroutineScope(Dispatchers.IO)
    private val prefs = context.getSharedPreferences("sangeet_prefs", Context.MODE_PRIVATE)

    private val _allSongs = MutableStateFlow<List<Song>>(emptyList())
    val allSongs: StateFlow<List<Song>> = _allSongs.asStateFlow()

    private val _playlists = MutableStateFlow<List<Playlist>>(emptyList())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    init {
        loadInitialCatalog()
        loadPlaylists()
    }

    private fun loadInitialCatalog() {
        val initialSongs = listOf(
            Song(
                id = "s1",
                title = "Raat Ka Safar",
                artist = "Arijit Vibe & Lofi Beats",
                album = "Midnight Chill Vol. 1",
                genre = "Lo-Fi",
                durationSeconds = 185,
                streamUrl = "https://raw.githubusercontent.com/rafaelreis-hotmart/Audio-Sample-files/master/sample.mp3",
                coverDrawableRes = R.drawable.album_raat_safar,
                coverColorHex = 0xFF7C3AED,
                lyrics = listOf(
                    LyricLine(0, "♪ (Lo-fi acoustic intro begins) ♪"),
                    LyricLine(6000, "Khamosh sadko pe hai ek haseen safar..."),
                    LyricLine(14000, "Sitaron ki roshni, thandi hawaon ka asar..."),
                    LyricLine(22000, "Dil dhoonde aisi manzil jahan sukoon mile..."),
                    LyricLine(31000, "Raat ka safar... dil ka humsafar..."),
                    LyricLine(42000, "♪ (Melodic piano & mellow beats) ♪"),
                    LyricLine(52000, "Har mod pe nayi kahani likhi jaati hai..."),
                    LyricLine(65000, "Chand ki chhaon mein khwabon ki nagri aati hai..."),
                    LyricLine(80000, "Raat ka safar... dil ka humsafar...")
                )
            ),
            Song(
                id = "s2",
                title = "Dil Ki Dharkan",
                artist = "Kabir Sharma",
                album = "Aashiqui Nights",
                genre = "Bollywood",
                durationSeconds = 210,
                streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
                coverDrawableRes = R.drawable.ic_app_foreground_logo,
                coverColorHex = 0xFFEC4899,
                lyrics = listOf(
                    LyricLine(0, "♪ (Gentle acoustic guitar strumming) ♪"),
                    LyricLine(8000, "Jab se dekha tujhe, yeh dil machal gaya..."),
                    LyricLine(18000, "Har lamha teri yaadon mein dhal gaya..."),
                    LyricLine(28000, "Tu jo paas hai toh saara jahan rangeen hai..."),
                    LyricLine(40000, "Dil ki yeh dharkan sirf tere liye hai..."),
                    LyricLine(55000, "Teri baaton mein aisi meethi khushbu hai..."),
                    LyricLine(70000, "Saans ruk jaye jab samne tu hai...")
                )
            ),
            Song(
                id = "s3",
                title = "Electric Storm",
                artist = "Nova Pulse & DJ Kren",
                album = "Cyber Neon 2026",
                genre = "EDM",
                durationSeconds = 195,
                streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
                coverDrawableRes = R.drawable.hero_music_banner,
                coverColorHex = 0xFF06B6D4,
                lyrics = listOf(
                    LyricLine(0, "♪ (Synth arpeggios charging) ♪"),
                    LyricLine(10000, "Feel the electric pulse in the dark..."),
                    LyricLine(20000, "Light up the arena with a spark!"),
                    LyricLine(30000, "♪ (BASS DROP) ♪"),
                    LyricLine(45000, "Never looking back, we fly tonight!"),
                    LyricLine(60000, "Through the cyber city neon light!")
                )
            ),
            Song(
                id = "s4",
                title = "Sufi Serenade",
                artist = "Rahat Soul Ensemble",
                album = "Ibaadat",
                genre = "Sufi",
                durationSeconds = 240,
                streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
                coverColorHex = 0xFFF59E0B,
                lyrics = listOf(
                    LyricLine(0, "♪ (Harmonium and peaceful flute alap) ♪"),
                    LyricLine(12000, "Rooh ki talash mein nikle the hum..."),
                    LyricLine(24000, "Teri rehmat ki chhaon mili har kadam..."),
                    LyricLine(38000, "Maula... mere maula... sukoon-e-dil tu hi..."),
                    LyricLine(54000, "Har saans mein tera naam hai ghoonja...")
                )
            ),
            Song(
                id = "s5",
                title = "Chai Aur Baarish",
                artist = "Ananya Roy",
                album = "Kolkata Monsoons",
                genre = "Indie",
                durationSeconds = 175,
                streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
                coverColorHex = 0xFF10B981,
                lyrics = listOf(
                    LyricLine(0, "♪ (Patter of rain drops & fingerpicked ukulele) ♪"),
                    LyricLine(7000, "Khidki pe baithi hoon, haath mein garam chai..."),
                    LyricLine(16000, "Bheege patton pe girti boondon ki lay..."),
                    LyricLine(28000, "Purani kitaabon ke panne palat rahe..."),
                    LyricLine(40000, "Baarish ke mausam mein khwaab machal rahe...")
                )
            ),
            Song(
                id = "s6",
                title = "Urban Rhythm",
                artist = "MC Zaid x BeatLab",
                album = "Gully Streets",
                genre = "Hip-Hop",
                durationSeconds = 160,
                streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
                coverColorHex = 0xFFE11D48,
                lyrics = listOf(
                    LyricLine(0, "♪ (Heavy 808 kick and hi-hat rolls) ♪"),
                    LyricLine(6000, "Raat ke do baje, kalam meri tez..."),
                    LyricLine(14000, "Sapne jo dekhe the unme hai craze..."),
                    LyricLine(24000, "Zindagi ek race nahi, apni yeh dhoon hai..."),
                    LyricLine(35000, "Apna time ayega nahi, apna time chal raha hai!")
                )
            ),
            Song(
                id = "s7",
                title = "Acoustic Sunset",
                artist = "Dev & Maya",
                album = "Goa Shorelines",
                genre = "Acoustic",
                durationSeconds = 200,
                streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3",
                coverColorHex = 0xFF8B5CF6,
                lyrics = listOf(
                    LyricLine(0, "♪ (Warm dual acoustic chords) ♪"),
                    LyricLine(9000, "Lehron ki aawaz suno gaur se..."),
                    LyricLine(20000, "Suraj dhal raha hai aasman ke chhor pe..."),
                    LyricLine(34000, "Har pal thehar jaye agar tum saath ho..."),
                    LyricLine(48000, "Yeh shaam kabhi na dhalne do...")
                )
            ),
            Song(
                id = "s8",
                title = "Retro Drive 1988",
                artist = "Neon Highway",
                album = "Outrun Horizons",
                genre = "Synthwave",
                durationSeconds = 190,
                streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3",
                coverColorHex = 0xFF3B82F6,
                lyrics = listOf(
                    LyricLine(0, "♪ (Arpeggiated analog synth intro) ♪"),
                    LyricLine(12000, "Cruising down the coastal line at 80 miles an hour..."),
                    LyricLine(25000, "Pastel neon lights glowing in the dusk..."),
                    LyricLine(40000, "The tape is playing our favorite retro track...")
                )
            )
        )

        // Read favorites from prefs
        val favIds = prefs.getStringSet("fav_ids", emptySet()) ?: emptySet()

        // Sync with download status
        val updated = initialSongs.map { song ->
            val isDownloaded = downloadManager.isSongDownloaded(song.id)
            val isFav = favIds.contains(song.id)
            song.copy(
                isDownloaded = isDownloaded,
                isFavorite = isFav
            )
        }

        _allSongs.value = updated

        // Pre-generate offline audio file for the top song so the user can immediately play offline
        scope.launch {
            try {
                if (!downloadManager.isSongDownloaded("s1")) {
                    val file = downloadManager.getDownloadedFile("s1")
                    val wav = AudioGenerator.createSongWavFile(context, "s1", 45)
                    wav.copyTo(file, overwrite = true)
                    setSongDownloaded("s1", true)
                }
            } catch (e: Exception) {
                // silent fallback
            }
        }
    }

    fun toggleFavorite(songId: String) {
        val currentList = _allSongs.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == songId }
        if (index != -1) {
            val oldSong = currentList[index]
            val newFav = !oldSong.isFavorite
            currentList[index] = oldSong.copy(isFavorite = newFav)
            _allSongs.value = currentList

            // Persist
            val favIds = prefs.getStringSet("fav_ids", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
            if (newFav) favIds.add(songId) else favIds.remove(songId)
            prefs.edit().putStringSet("fav_ids", favIds).apply()
        }
    }

    fun setSongDownloaded(songId: String, isDownloaded: Boolean) {
        val currentList = _allSongs.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == songId }
        if (index != -1) {
            currentList[index] = currentList[index].copy(isDownloaded = isDownloaded)
            _allSongs.value = currentList
        }
    }

    fun markAllAsDownloadedState() {
        val currentList = _allSongs.value.map { song ->
            song.copy(isDownloaded = downloadManager.isSongDownloaded(song.id))
        }
        _allSongs.value = currentList
    }

    private fun loadPlaylists() {
        _playlists.value = listOf(
            Playlist(
                id = "pl_chill",
                title = "Late Night Chill",
                description = "Relaxing Lo-fi & Acoustic melodies for peaceful nights",
                songIds = listOf("s1", "s4", "s5")
            ),
            Playlist(
                id = "pl_energy",
                title = "Workout & Energy",
                description = "Fast-paced EDM and Urban beats to keep your adrenaline high",
                songIds = listOf("s3", "s6", "s8")
            ),
            Playlist(
                id = "pl_bollywood",
                title = "Romantic Dil Se",
                description = "Heartwarming romantic tracks and soulful melodies",
                songIds = listOf("s1", "s2", "s7")
            )
        )
    }

    fun createPlaylist(title: String, description: String) {
        val newPl = Playlist(
            id = "pl_${System.currentTimeMillis()}",
            title = title.ifBlank { "My Playlist" },
            description = description.ifBlank { "Custom user playlist" },
            songIds = emptyList()
        )
        _playlists.value = _playlists.value + newPl
    }

    fun addSongToPlaylist(playlistId: String, songId: String) {
        val current = _playlists.value.toMutableList()
        val index = current.indexOfFirst { it.id == playlistId }
        if (index != -1) {
            val pl = current[index]
            if (!pl.songIds.contains(songId)) {
                current[index] = pl.copy(songIds = pl.songIds + songId)
                _playlists.value = current
            }
        }
    }

    fun removeSongFromPlaylist(playlistId: String, songId: String) {
        val current = _playlists.value.toMutableList()
        val index = current.indexOfFirst { it.id == playlistId }
        if (index != -1) {
            val pl = current[index]
            current[index] = pl.copy(songIds = pl.songIds - songId)
            _playlists.value = current
        }
    }
}
