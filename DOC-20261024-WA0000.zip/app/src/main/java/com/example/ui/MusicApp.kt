package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.DownloadDone
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.QueueMusic
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.ui.components.EqualizerDialog
import com.example.ui.components.MiniPlayer
import com.example.ui.components.NowPlayingSheet
import com.example.ui.components.SleepTimerDialog
import com.example.ui.screens.AddToPlaylistDialog
import com.example.ui.screens.CreatePlaylistDialog
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PlaylistsScreen
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MusicViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicApp(
    viewModel: MusicViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var isSearchActive by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissSnackbar()
        }
    }

    Scaffold(
        containerColor = ObsidianBlack,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianBlack)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Brand Header Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(NeonCyan),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_app_foreground_logo),
                            contentDescription = "Sangeet App Logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(36.dp).clip(CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Sangeet",
                                color = TextPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = (-0.5).sp
                            )
                            if (uiState.isOfflineModeOnly) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = EmeraldGreen.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "OFFLINE",
                                        color = EmeraldGreen,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Search Toggle Icon
                    IconButton(
                        onClick = {
                            isSearchActive = !isSearchActive
                            if (!isSearchActive) viewModel.onSearchQueryChange("")
                        },
                        modifier = Modifier.testTag("search_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isSearchActive) Icons.Default.Clear else Icons.Default.Search,
                            contentDescription = "Search",
                            tint = if (isSearchActive) NeonCyan else TextPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Expandable Search Bar
                AnimatedVisibility(visible = isSearchActive) {
                    OutlinedTextField(
                        value = uiState.searchQuery,
                        onValueChange = { viewModel.onSearchQueryChange(it) },
                        placeholder = { Text("Search songs, artists, genres...", color = TextMuted) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary)
                        },
                        trailingIcon = {
                            if (uiState.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.onSearchQueryChange("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkCardSurface,
                            focusedContainerColor = DarkSurfaceElevated,
                            unfocusedContainerColor = DarkSurfaceElevated,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .testTag("search_text_input")
                    )
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianBlack)
                    .navigationBarsPadding()
            ) {
                // Mini Player docked above NavigationBar
                if (uiState.currentSong != null) {
                    MiniPlayer(
                        song = uiState.currentSong!!,
                        isPlaying = uiState.isPlaying,
                        currentPositionMs = uiState.currentPositionMs,
                        durationMs = uiState.durationMs,
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onSkipNext = { viewModel.playNext() },
                        onExpand = { viewModel.setNowPlayingExpanded(true) }
                    )
                }

                // Material 3 Navigation Bar
                NavigationBar(
                    containerColor = DarkSurface,
                    tonalElevation = 8.dp,
                    modifier = Modifier.height(64.dp)
                ) {
                    NavigationBarItem(
                        selected = uiState.currentTab == MainTab.HOME,
                        onClick = { viewModel.selectTab(MainTab.HOME) },
                        icon = {
                            Icon(
                                if (uiState.currentTab == MainTab.HOME) Icons.Default.Home else Icons.Outlined.Home,
                                contentDescription = "Home"
                            )
                        },
                        label = { Text("Explore", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = NeonCyan,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_tab_home")
                    )

                    NavigationBarItem(
                        selected = uiState.currentTab == MainTab.DOWNLOADS,
                        onClick = { viewModel.selectTab(MainTab.DOWNLOADS) },
                        icon = {
                            Icon(
                                if (uiState.currentTab == MainTab.DOWNLOADS) Icons.Default.DownloadDone else Icons.Outlined.DownloadDone,
                                contentDescription = "Offline"
                            )
                        },
                        label = { Text("Offline", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = EmeraldGreen,
                            indicatorColor = EmeraldGreen,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_tab_downloads")
                    )

                    NavigationBarItem(
                        selected = uiState.currentTab == MainTab.FAVORITES,
                        onClick = { viewModel.selectTab(MainTab.FAVORITES) },
                        icon = {
                            Icon(
                                if (uiState.currentTab == MainTab.FAVORITES) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "Favorites"
                            )
                        },
                        label = { Text("Liked", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = NeonCyan,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_tab_favorites")
                    )

                    NavigationBarItem(
                        selected = uiState.currentTab == MainTab.PLAYLISTS,
                        onClick = { viewModel.selectTab(MainTab.PLAYLISTS) },
                        icon = {
                            Icon(
                                if (uiState.currentTab == MainTab.PLAYLISTS) Icons.Default.QueueMusic else Icons.Outlined.QueueMusic,
                                contentDescription = "Playlists"
                            )
                        },
                        label = { Text("Playlists", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = NeonCyan,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_tab_playlists")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.currentTab) {
                MainTab.HOME -> {
                    HomeScreen(
                        uiState = uiState,
                        onSelectGenre = { viewModel.selectGenre(it) },
                        onToggleOfflineMode = { viewModel.toggleOfflineModeOnly() },
                        onPlaySong = { viewModel.playSong(it) },
                        onDownloadSong = { viewModel.downloadSong(it) },
                        onDeleteDownload = { viewModel.deleteDownload(it) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        onAddToPlaylist = { viewModel.openAddToPlaylist(it) }
                    )
                }
                MainTab.DOWNLOADS -> {
                    DownloadsScreen(
                        uiState = uiState,
                        onPlaySong = { viewModel.playSong(it, uiState.downloadedSongs) },
                        onPlayAll = {
                            if (uiState.downloadedSongs.isNotEmpty()) {
                                viewModel.playSong(uiState.downloadedSongs.first(), uiState.downloadedSongs)
                            }
                        },
                        onDeleteDownload = { viewModel.deleteDownload(it) },
                        onClearAllDownloads = { viewModel.clearAllDownloads() },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        onAddToPlaylist = { viewModel.openAddToPlaylist(it) }
                    )
                }
                MainTab.FAVORITES -> {
                    FavoritesScreen(
                        uiState = uiState,
                        onPlaySong = { viewModel.playSong(it, uiState.favoriteSongs) },
                        onPlayAll = {
                            if (uiState.favoriteSongs.isNotEmpty()) {
                                viewModel.playSong(uiState.favoriteSongs.first(), uiState.favoriteSongs)
                            }
                        },
                        onShuffleAll = {
                            if (uiState.favoriteSongs.isNotEmpty()) {
                                if (!uiState.isShuffle) viewModel.toggleShuffle()
                                viewModel.playSong(uiState.favoriteSongs.random(), uiState.favoriteSongs)
                            }
                        },
                        onDownloadSong = { viewModel.downloadSong(it) },
                        onDeleteDownload = { viewModel.deleteDownload(it) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        onAddToPlaylist = { viewModel.openAddToPlaylist(it) }
                    )
                }
                MainTab.PLAYLISTS -> {
                    PlaylistsScreen(
                        uiState = uiState,
                        onOpenCreateDialog = { viewModel.setShowCreatePlaylistDialog(true) },
                        onPlaySong = { viewModel.playSong(it) },
                        onDownloadSong = { viewModel.downloadSong(it) },
                        onDeleteDownload = { viewModel.deleteDownload(it) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        onAddToPlaylist = { viewModel.openAddToPlaylist(it) }
                    )
                }
            }
        }
    }

    // Full Screen Now Playing Sheet
    if (uiState.isNowPlayingExpanded && uiState.currentSong != null) {
        NowPlayingSheet(
            song = uiState.currentSong!!,
            isPlaying = uiState.isPlaying,
            currentPositionMs = uiState.currentPositionMs,
            durationMs = uiState.durationMs,
            playbackSpeed = uiState.playbackSpeed,
            repeatMode = uiState.repeatMode,
            isShuffle = uiState.isShuffle,
            equalizerPreset = uiState.equalizerPreset,
            sleepTimerSeconds = uiState.sleepTimerSeconds,
            visualizerBars = uiState.visualizerAmplitudes,
            downloadProgress = uiState.downloadProgressMap[uiState.currentSong!!.id],
            showLyrics = uiState.showLyricsSheet,
            onDismiss = { viewModel.setNowPlayingExpanded(false) },
            onTogglePlayPause = { viewModel.togglePlayPause() },
            onSeek = { viewModel.seekTo(it) },
            onSkipNext = { viewModel.playNext() },
            onSkipPrev = { viewModel.playPrevious() },
            onSkip10Forward = { viewModel.skipForward() },
            onSkip10Backward = { viewModel.skipBackward() },
            onToggleShuffle = { viewModel.toggleShuffle() },
            onToggleRepeat = { viewModel.toggleRepeat() },
            onToggleFavorite = { viewModel.toggleFavorite(it) },
            onDownloadClick = { viewModel.downloadSong(it) },
            onSetPlaybackSpeed = { viewModel.setPlaybackSpeed(it) },
            onOpenEqualizer = { viewModel.setShowEqualizerDialog(true) },
            onOpenSleepTimer = { viewModel.setShowSleepTimerDialog(true) },
            onToggleLyrics = { viewModel.setShowLyricsSheet(!uiState.showLyricsSheet) }
        )
    }

    // Equalizer Dialog
    if (uiState.showEqualizerDialog) {
        EqualizerDialog(
            currentPreset = uiState.equalizerPreset,
            onSelectPreset = { viewModel.setEqualizerPreset(it) },
            onDismiss = { viewModel.setShowEqualizerDialog(false) }
        )
    }

    // Sleep Timer Dialog
    if (uiState.showSleepTimerDialog) {
        SleepTimerDialog(
            currentTimerRemaining = uiState.sleepTimerSeconds,
            onSetTimer = { viewModel.setSleepTimer(it) },
            onDismiss = { viewModel.setShowSleepTimerDialog(false) }
        )
    }

    // Create Playlist Dialog
    if (uiState.showCreatePlaylistDialog) {
        CreatePlaylistDialog(
            onCreate = { title, desc -> viewModel.createPlaylist(title, desc) },
            onDismiss = { viewModel.setShowCreatePlaylistDialog(false) }
        )
    }

    // Add To Playlist Dialog
    if (uiState.songForPlaylistAddition != null) {
        AddToPlaylistDialog(
            song = uiState.songForPlaylistAddition!!,
            playlists = uiState.playlists,
            onSelectPlaylist = { pl -> viewModel.addSongToPlaylist(pl, uiState.songForPlaylistAddition!!) },
            onDismiss = { viewModel.closeAddToPlaylist() }
        )
    }
}
