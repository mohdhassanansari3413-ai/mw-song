package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand accents
val NeonCyan = Color(0xFF00E5FF)
val ElectricViolet = Color(0xFFA855F7)
val VividPink = Color(0xFFFF2E93)
val EmeraldGreen = Color(0xFF10B981)
val AmberOrange = Color(0xFFF59E0B)

// Dark background & surface palette (Luxury Dark Music Vibe)
val ObsidianBlack = Color(0xFF0A0D14)
val DarkSurface = Color(0xFF121722)
val DarkSurfaceElevated = Color(0xFF1B2232)
val DarkCardSurface = Color(0xFF1F2839)
val DarkBorder = Color(0xFF2E384D)

// Text tokens
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Light fallback tokens
val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightPrimary = Color(0xFF0891B2)
