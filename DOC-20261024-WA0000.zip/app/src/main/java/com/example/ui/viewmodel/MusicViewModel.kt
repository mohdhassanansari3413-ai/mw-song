package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.audio.AudioPlayerManager
import com.example.data.downloader.SongDownloadManager
import com.example.data.model.DownloadProgress
import com.example.data.model.EqualizerPreset
import com.example.data.model.Playlist
import com.example.data.model.RepeatMode
import com.example.data.model.Song
import com.example.data.repository.MusicRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab(val title: String) {
    HOME("Home"),
    DOWNLOADS("Offline"),
    FAVORITES("Liked"),
    PLAYLISTS("Playlists")
}

data class MusicUiState(
    val currentTab: MainTab = MainTab.HOME,
    val searchQuery: String = "",
    val selectedGenre: String = "All",
    val isOfflineModeOnly: Boolean = false,
    val allSongs: List<Song> = emptyList(),
    val displayedSongs: List<Song> = emptyList(),
    val downloadedSongs: List<Song> = emptyList(),
    val favoriteSongs: List<Song> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val currentSong: Song? = null,
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackSpeed: Float = 1.0f,
    val repeatMode: RepeatMode = RepeatMode.ALL,
    val isShuffle: Boolean = false,
    val equalizerPreset: EqualizerPreset = EqualizerPreset.FLAT,
    val sleepTimerSeconds: Int? = null,
    val visualizerAmplitudes: List<Float> = List(16) { 0.2f },
    val downloadProgressMap: Map<String, DownloadProgress> = emptyMap(),
    val storageUsedMb: Float = 0f,
    val isNowPlayingExpanded: Boolean = false,
    val showEqualizerDialog: Boolean = false,
    val showSleepTimerDialog: Boolean = false,
    val showLyricsSheet: Boolean = false,
    val showCreatePlaylistDialog: Boolean = false,
    val songForPlaylistAddition: Song? = null,
    val snackbarMessage: String? = null
)

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    val downloadManager = SongDownloadManager(application)
    val audioPlayerManager = AudioPlayerManager(application)
    val repository = MusicRepository(application, downloadManager)

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    private val _searchQuery = MutableStateFlow("")
    private val _selectedGenre = MutableStateFlow("All")
    private val _isOfflineModeOnly = MutableStateFlow(false)
    private val _isNowPlayingExpanded = MutableStateFlow(false)
    private val _showEqualizerDialog = MutableStateFlow(false)
    private val _showSleepTimerDialog = MutableStateFlow(false)
    private val _showLyricsSheet = MutableStateFlow(false)
    private val _showCreatePlaylistDialog = MutableStateFlow(false)
    private val _songForPlaylistAddition = MutableStateFlow<Song?>(null)
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    private val _storageUsedMb = MutableStateFlow(downloadManager.getTotalStorageUsedMb())

    val uiState: StateFlow<MusicUiState> = combine(
        combine(
            _currentTab,
            _searchQuery,
            _selectedGenre,
            _isOfflineModeOnly,
            repository.allSongs
        ) { tab, query, genre, offlineOnly, allSongs ->
            TabFilterData(tab, query, genre, offlineOnly, allSongs)
        },
        combine(
            repository.playlists,
            audioPlayerManager.currentSong,
            audioPlayerManager.isPlaying,
            audioPlayerManager.currentPositionMs,
            audioPlayerManager.durationMs
        ) { playlists, song, isPlaying, pos, dur ->
            PlayerBasicData(playlists, song, isPlaying, pos, dur)
        },
        combine(
            audioPlayerManager.playbackSpeed,
            audioPlayerManager.repeatMode,
            audioPlayerManager.isShuffle,
            audioPlayerManager.equalizerPreset,
            audioPlayerManager.sleepTimerSeconds
        ) { speed, repeat, shuffle, eq, sleep ->
            PlayerSettingsData(speed, repeat, shuffle, eq, sleep)
        },
        combine(
            audioPlayerManager.visualizerAmplitudes,
            downloadManager.downloadProgressMap,
            _storageUsedMb,
            _isNowPlayingExpanded,
            _snackbarMessage
        ) { vis, dlMap, storage, expanded, snack ->
            UiModalData(vis, dlMap, storage, expanded, snack)
        }
    ) { filter, playerBasic, playerSettings, uiModal ->

        val songsToFilter = if (filter.offlineOnly || filter.tab == MainTab.DOWNLOADS) {
            filter.allSongs.filter { it.isDownloaded }
        } else {
            filter.allSongs
        }

        val filtered = songsToFilter.filter { song ->
            val matchesGenre = filter.genre == "All" || song.genre.equals(filter.genre, ignoreCase = true)
            val matchesQuery = filter.query.isBlank() ||
                song.title.contains(filter.query, ignoreCase = true) ||
                song.artist.contains(filter.query, ignoreCase = true) ||
                song.album.contains(filter.query, ignoreCase = true)
            matchesGenre && matchesQuery
        }

        val downloaded = filter.allSongs.filter { it.isDownloaded }
        val favorites = filter.allSongs.filter { it.isFavorite }

        MusicUiState(
            currentTab = filter.tab,
            searchQuery = filter.query,
            selectedGenre = filter.genre,
            isOfflineModeOnly = filter.offlineOnly,
            allSongs = filter.allSongs,
            displayedSongs = filtered,
            downloadedSongs = downloaded,
            favoriteSongs = favorites,
            playlists = playerBasic.playlists,
            currentSong = playerBasic.song,
            isPlaying = playerBasic.isPlaying,
            currentPositionMs = playerBasic.pos,
            durationMs = playerBasic.dur,
            playbackSpeed = playerSettings.speed,
            repeatMode = playerSettings.repeat,
            isShuffle = playerSettings.shuffle,
            equalizerPreset = playerSettings.eq,
            sleepTimerSeconds = playerSettings.sleep,
            visualizerAmplitudes = uiModal.vis,
            downloadProgressMap = uiModal.dlMap,
            storageUsedMb = uiModal.storage,
            isNowPlayingExpanded = uiModal.expanded,
            showEqualizerDialog = _showEqualizerDialog.value,
            showSleepTimerDialog = _showSleepTimerDialog.value,
            showLyricsSheet = _showLyricsSheet.value,
            showCreatePlaylistDialog = _showCreatePlaylistDialog.value,
            songForPlaylistAddition = _songForPlaylistAddition.value,
            snackbarMessage = uiModal.snack
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        MusicUiState()
    )

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun selectGenre(genre: String) {
        _selectedGenre.value = genre
    }

    fun toggleOfflineModeOnly() {
        val newVal = !_isOfflineModeOnly.value
        _isOfflineModeOnly.value = newVal
        showSnackbar(if (newVal) "Offline Mode ON: Showing downloaded music only" else "Online Mode: Full catalog active")
    }

    fun playSong(song: Song, queue: List<Song> = emptyList()) {
        val targetQueue = if (queue.isNotEmpty()) queue else uiState.value.displayedSongs
        audioPlayerManager.playSong(song, targetQueue)
    }

    fun togglePlayPause() {
        audioPlayerManager.togglePlayPause()
    }

    fun seekTo(positionMs: Long) {
        audioPlayerManager.seekTo(positionMs)
    }

    fun skipForward() {
        audioPlayerManager.skipForward10()
    }

    fun skipBackward() {
        audioPlayerManager.skipBackward10()
    }

    fun playNext() {
        audioPlayerManager.playNext()
    }

    fun playPrevious() {
        audioPlayerManager.playPrevious()
    }

    fun toggleShuffle() {
        audioPlayerManager.toggleShuffle()
    }

    fun toggleRepeat() {
        audioPlayerManager.toggleRepeatMode()
    }

    fun setPlaybackSpeed(speed: Float) {
        audioPlayerManager.setPlaybackSpeed(speed)
        showSnackbar("Playback speed set to ${speed}x")
    }

    fun setEqualizerPreset(preset: EqualizerPreset) {
        audioPlayerManager.setEqualizerPreset(preset)
        _showEqualizerDialog.value = false
        showSnackbar("Equalizer preset: ${preset.label}")
    }

    fun setSleepTimer(minutes: Int) {
        audioPlayerManager.setSleepTimer(minutes)
        _showSleepTimerDialog.value = false
        if (minutes > 0) {
            showSnackbar("Sleep timer set for $minutes minutes")
        } else {
            showSnackbar("Sleep timer cancelled")
        }
    }

    fun toggleFavorite(song: Song) {
        repository.toggleFavorite(song.id)
        val willBeFav = !song.isFavorite
        showSnackbar(if (willBeFav) "Added to Liked Songs ❤️" else "Removed from Liked Songs")
    }

    fun downloadSong(song: Song) {
        if (song.isDownloaded) {
            showSnackbar("\"${song.title}\" is already downloaded for offline playback!")
            return
        }

        showSnackbar("Downloading \"${song.title}\" for offline use...")
        viewModelScope.launch {
            downloadManager.downloadSong(
                song = song,
                onComplete = { file ->
                    repository.setSongDownloaded(song.id, true)
                    _storageUsedMb.value = downloadManager.getTotalStorageUsedMb()
                    showSnackbar("Downloaded \"${song.title}\"! Ready for offline play 🎵")
                },
                onError = { err ->
                    showSnackbar("Download error: $err")
                }
            )
        }
    }

    fun deleteDownload(song: Song) {
        viewModelScope.launch {
            val deleted = downloadManager.deleteDownload(song.id)
            if (deleted) {
                repository.setSongDownloaded(song.id, false)
                _storageUsedMb.value = downloadManager.getTotalStorageUsedMb()
                showSnackbar("Removed \"${song.title}\" from downloads")
            }
        }
    }

    fun clearAllDownloads() {
        viewModelScope.launch {
            downloadManager.clearAllDownloads()
            repository.markAllAsDownloadedState()
            _storageUsedMb.value = 0f
            showSnackbar("All downloaded songs cleared")
        }
    }

    fun createPlaylist(title: String, description: String) {
        repository.createPlaylist(title, description)
        _showCreatePlaylistDialog.value = false
        showSnackbar("Playlist \"$title\" created!")
    }

    fun openAddToPlaylist(song: Song) {
        _songForPlaylistAddition.value = song
    }

    fun closeAddToPlaylist() {
        _songForPlaylistAddition.value = null
    }

    fun addSongToPlaylist(playlist: Playlist, song: Song) {
        repository.addSongToPlaylist(playlist.id, song.id)
        _songForPlaylistAddition.value = null
        showSnackbar("Added \"${song.title}\" to ${playlist.title}")
    }

    fun setNowPlayingExpanded(expanded: Boolean) {
        _isNowPlayingExpanded.value = expanded
    }

    fun setShowEqualizerDialog(show: Boolean) {
        _showEqualizerDialog.value = show
    }

    fun setShowSleepTimerDialog(show: Boolean) {
        _showSleepTimerDialog.value = show
    }

    fun setShowLyricsSheet(show: Boolean) {
        _showLyricsSheet.value = show
    }

    fun setShowCreatePlaylistDialog(show: Boolean) {
        _showCreatePlaylistDialog.value = show
    }

    fun dismissSnackbar() {
        _snackbarMessage.value = null
    }

    private fun showSnackbar(msg: String) {
        _snackbarMessage.value = msg
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayerManager.release()
    }
}

// Internal helper data classes for combine
private data class TabFilterData(
    val tab: MainTab,
    val query: String,
    val genre: String,
    val offlineOnly: Boolean,
    val allSongs: List<Song>
)

private data class PlayerBasicData(
    val playlists: List<Playlist>,
    val song: Song?,
    val isPlaying: Boolean,
    val pos: Long,
    val dur: Long
)

private data class PlayerSettingsData(
    val speed: Float,
    val repeat: RepeatMode,
    val shuffle: Boolean,
    val eq: EqualizerPreset,
    val sleep: Int?
)

private data class UiModalData(
    val vis: List<Float>,
    val dlMap: Map<String, DownloadProgress>,
    val storage: Float,
    val expanded: Boolean,
    val snack: String?
)
