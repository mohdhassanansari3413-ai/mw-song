package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Song
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app_name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Sangeet", appName)
    }

    @Test
    fun `song duration formatting works correctly`() {
        val song = Song(
            id = "test_1",
            title = "Test Song",
            artist = "Test Artist",
            album = "Test Album",
            genre = "Lo-Fi",
            durationSeconds = 185,
            streamUrl = "https://example.com/audio.mp3"
        )
        assertEquals("3:05", song.durationFormatted)
    }
}
